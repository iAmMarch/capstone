<?php 
session_start();
require_once 'db.php';
include 'include/home/header.php'; 

$uid = $_SESSION['customerid'];
$cart = $_SESSION['cart'];
?>

	
	<!-- SHOP CONTENT -->
	<section id="content">
		<div class="content-blog">
			<div class="container">
				<div class="row">
					<div class="page_header text-center">
						<h2>Shopping Cart</h2>
						<p>Get the best items from Hablon de Cebu</p>
					</div>
					<div class="col-md-12">

<table class="cart-table table table-bordered">
				<thead>
					<tr>
						<th>Action</th>
						<th>Image</th>
						<th>Product</th>
						<th>Price</th>
						<th>Quantity</th>
						<th>Total</th>
					</tr>
				</thead>
				
				<?php

				
					//print_r($cart);
				$total = 0;
					foreach ($cart as $key => $value) {
						//echo $key . " : " . $value['quantity'] ."<br>";
						$cartsql = "SELECT * FROM products WHERE id=$key";
						$cartres = mysqli_query($connection, $cartsql);
						$cartr = mysqli_fetch_assoc($cartres);

					
				 ?>
					<tr>
						<td>
							<a class="remove" href="delcart.php?id=<?php echo $key; ?>"><i class="fa fa-times"></i>Delete</a>
						</td>
						<td>
							<a href="#"><img src="<?php echo $cartr['thumb']; ?>" alt="" height="90" width="90"></a>					
						</td>
						<td>
							<a href="details.php?id=<?php echo $cartr['id']; ?>"><?php echo substr($cartr['name'], 0 , 30); ?></a>					
						</td>
						<td>
							<span class="amount">$<?php echo $cartr['price']; ?></span>					
						</td>
						<td>
							<div class="quantity"><?php echo $value['quantity']; ?></div>
						</td>
						<td>
							<span class="amount">$<?php echo $english_format_number = number_format(($cartr['price']*$value['quantity'])); ?></span>					
						</td>
					</tr>
				<?php 
					$total = $total + ($cartr['price']*$value['quantity']);
				} ?>
					<tr>
						<td colspan="6" class="actions">
							<div class="col-md-6">
							<!--	<div class="coupon">
									<label>Coupon:</label><br>
									<input placeholder="Coupon code" type="text"> <button type="submit">Apply</button>
								</div> -->
							</div>
							<div class="col-md-6">
								<div class="cart-btn">
									<a href="shop.php" class="button btn-md" >Continue Shopping ||</a>
									<a href="orders.php" class="button btn-md" >View Orders ||</a>
									<!-- <button class="button btn-md" type="submit">Update Cart</button> -->
									<a href="pay.php" class="button btn-md" >Checkout</a>
								</div>
							</div>
						</td>
						
					</tr>
				</tbody>
			</table>		

			<div class="cart_totals">
				<div class="col-md-6 push-md-6 no-padding">
					<h4 class="heading">Cart Totals</h4>
							<table class="table table-bordered col-md-6">
						<tbody>
							<tr>
								<th>Cart Subtotal</th>
								<td><span class="amount">$ <?php echo $total; ?></span></td>
							</tr>
						</tbody>
					</table>
						<div class="ma-address">
		<h3>My Addresses</h3>
			<p>The following addresses will be used on the checkout page by default.</p>

	<div class="row">
		<div class="col-md-6">
			<h4>My Address <a href="#">Edit</a></h4>
				<?php
					$csql = "SELECT u1.firstname, u1.lastname, u1.address1, u1.city, u1.state, u.email, u1.mobile, u1.zip FROM users u JOIN usersmeta u1 WHERE u.id=u1.uid AND u.id=$uid";
						
							$cres = mysqli_query($connection, $csql);
							while($cr = mysqli_fetch_assoc($cres)){
					?>
					<p>First Name: <?php echo $cr['firstname']; ?></p>
					<p>Last Name: <?php echo $cr['lastname']; ?></p>
					<p>Address: <?php echo $cr['address1']; ?></p>
					<p>City: <?php echo $cr['city']; ?></p>
					<p>Zip: <?php echo $cr['zip']; ?></p>
					<p>Mobile: <?php echo $cr['mobile']; ?></p>
					<p>Email: <?php echo $cr['email']; ?></p>

					<?php } ?>
		</div>
	</div>
</div>

				</div>
					
			</div>	<!----->
				
		</div>
	</div>
	
</div>
</div>
</section>



