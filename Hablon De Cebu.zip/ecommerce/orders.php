<?php
	ob_start();
	session_start();
	include 'db.php';
	if(!isset($_SESSION['username']) & empty($_SESSION['username'])){
		header('location: index.php');
	}
include 'include/home/header.php'; 

$uid = $_SESSION['customerid'];
$cart = $_SESSION['cart'];
?>
	
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php echo "<h1>" . $_SESSION['username'] . " Orders</h1>" ; ?>
<table class="cart-table account-table table table-bordered">
				<thead>
					<tr>
						<th>Order No.</th>
						<th>Date</th>
						<th>Status</th>
						<th>Total</th>
						<th></th>
					</tr>
				</thead>
				<tbody>

				<?php
					$ordsql = "SELECT * FROM orders WHERE uid='$uid'";
					$ordres = mysqli_query($connection, $ordsql);
					while($ordr = mysqli_fetch_assoc($ordres)){
				?>
					<tr>
						<td>
							<?php echo $ordr['id']; ?>
						</td>
						<td>
							<?php echo $ordr['timestamp']; ?>
						</td>
						<td>
							<?php echo $ordr['orderstatus']; ?>			
						</td>
						
						<td>
							$ <?php echo number_format($ordr['totalprice'],2); ?>
						</td>
						<td>
							<a href="#?id=<?php echo $ordr['id']; ?>">View</a>
							<!--<?php if($ordr['orderstatus'] != 'Cancelled'){?>
							| <a href="cancel-order.php?id=<?php echo $ordr['id']; ?>">Cancel</a>
							<?php } ?>-->
						</td>
					</tr>
				<?php } ?>
				</tbody>
			</table>		
</body>
</html>