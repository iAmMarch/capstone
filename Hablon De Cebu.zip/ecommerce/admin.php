<?php 
include('db.php');
session_start();
include('include/admin/header.php');

	if(!isset($_SESSION['username']) & empty($_SESSION['username'])){
		header('location: index.php');
	}
?>
    <section>
		<div class="container">
			<div class="row">
				<?php include('include/admin/sidebar.php');?>

                    
    <div class="col-sm-9 padding-right">
					<div class="features_items"><!--features_items-->
						<h2 class="title text-center">All Products</h2>
                        
          
          					<label for="filter">Filter</label> <input type="text" name="filter" value="" id="" />
					<a rel="facebox" href="addproduct.php">Add Product</a>
					<table cellpadding="1" cellspacing="1" id="resultTable">
						<thead>
							<tr>
								<th  style="border-left: 1px solid #C1DAD7"> ID </th>
								<th> Image </th>
								<th> Product </th>
								<th> Desciption </th>
								<th> Price </th>
								<th> Category </th>
                                <th> Action </th>
							</tr>
						</thead>
						<tbody>
						<?php
						
								$sql = "SELECT * FROM products";
					$res = mysqli_query($connection, $sql); 
					while ($r = mysqli_fetch_assoc($res))
								{
									?>
									<tr class="record">';
									<td style="border-left: 1px solid #C1DAD7;"><?php echo $r['id'];?></td>
									<td><a rel="facebox" href="#?id='.$r['id'].'"><img src="<?php echo $r['thumb'];?>" width="80" height="50"></a></td>
									<td><div align="right"><?php echo $r['name'];?></div></td>
									<td><div align="right"><?php echo $r['description'];?></div></td>
									<td><div align="right"><?php echo $r['price'];?></div></td>
									<td><div align="right"><?php echo $r['catid'];?></div></td>	
									<td><div align="center"><a rel="facebox" href="editproductdetails.php?id=<?php echo ['id'];?>">Edit</a> &nbsp;&nbsp; <br><br>
									<a href="deleteprod.php? id=<?php echo  $r['id'];?>" class="delbutton" >Delete</a></div></td>
									echo '</tr>';
								<?php } ?>
						</tbody>
					</table>
              </section>
            