<?php include('include/home/header.php');
		include('db.php');
		 ?>

    	<section>
		<div class="container">
			<div class="row">
			
<?php include('include/home/sidebar.php'); ?>
                    
    <div class="col-sm-9 padding-right">
					<div class="features_items"><!--features_items-->
						<h2 class="title text-center">All Products</h2>

	

<?php				
				
				$sql = "SELECT * FROM products";
								if(isset($_GET['id']) & !empty($_GET['id'])){
									$id = $_GET['id'];
									$sql .= " WHERE catid=$id";
								}
								

								$res = mysqli_query($connection, $sql);
								while($r = mysqli_fetch_assoc($res)){
					?>
				
					<ul class="col-sm-4">
					<div class="product-image-wrapper">
						  <div class="single-products">
						  <div class="productinfo text-center">
					<img src="<?php echo $r['thumb']; ?>" width="150" height="150">
                    <h3><?php echo $r['name']; ?></h3>
					
					<h2>Price: <?php echo $english_format_number = number_format($r['price']); ?></h2>
					<a href="details.php?id=<?php echo $r['id']; ?>" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>View Details</a>
					</div>	
					</ul>	
				<?php } ?>
<!--php ends here-->
			</div>
        </div>
</div>
</div>
</div>
</section>