<?php
$connection = mysqli_connect('localhost', 'root', '', 'dbgadget');
if(!$connection){
	echo "Error: Unable to connect to MySQL." . PHP_EOL;
    echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
    echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
    exit;
}
?>


<!-- SET @num :=0;

UPDATE orderitems SET id = @num :=(@num+1);
ALTER TABLE orderitems AUTO_INCREMENT =1; -->