<?php
	ob_start();
	session_start();
	require_once 'db.php';
	if(!isset($_SESSION['username']) & empty($_SESSION['username'])){
		header('location: index.php');
	}
include 'include/home/header.php'; 

$uid = $_SESSION['customerid'];
$cart = $_SESSION['cart'];
?>
			<table class="table table-bordered extra-padding">
				<?php

	$total = 0;
				foreach ($cart as $key => $value) {
					//echo $key . " : " . $value['quantity'] ."<br>";
					$ordsql = "SELECT * FROM products WHERE id=$key";
					$ordres = mysqli_query($connection, $ordsql);
					$ordr = mysqli_fetch_assoc($ordres);

					$total = $total + ($ordr['price']*$value['quantity']);
				}
$iosql = "INSERT INTO orders (uid, totalprice, orderstatus) VALUES ('$uid', '$total', 'Order Placed')";
				$iores = mysqli_query($connection, $iosql) or die(mysqli_error($connection));
				if($iores){
					//echo "Order inserted, insert order items <br>";
					$orderid = mysqli_insert_id($connection);
					foreach ($cart as $key => $value) {
						//echo $key . " : " . $value['quantity'] ."<br>";
						$ordsql = "SELECT * FROM products WHERE id=$key";
						$ordres = mysqli_query($connection, $ordsql);
						$ordr = mysqli_fetch_assoc($ordres);

						$pid = $ordr['id'];
						$productprice = $ordr['price'];
						$quantity = $value['quantity'];


						$orditmsql = "INSERT INTO orderitems (pid, orderid, productprice, pquantity) VALUES ('$pid', '$orderid', '$productprice', '$quantity')";
						$orditmres = mysqli_query($connection, $orditmsql) or die(mysqli_error($connection));
						//if($orditmres){
							//echo "Order Item inserted redirect to my account page <br>";
						//}
					}
				}
				unset($_SESSION['cart']);
				?>
				<div class="space30"></div>
			<h1 class="heading">Your order</h1>
			<form method="post">
					<table class="table table-bordered extra-padding">
				<tbody>
						<tr>
							<th>Order Total</th>
							<td><span class="amount">$ <?php echo $total; ?></span></td>
							<td><a href="cart.php"><i class="fa fa-arrow-left">Back to Cart</i></a>
							</td>
							</tr>
						</tbody>
					
				</table>
			
			
			
			
				<div class="space30"></div>
				
					<input name="agree" id="checkboxG2" class="css-checkbox" type="checkbox" value="true"><span>I've read and accept the <a href="#">terms &amp; conditions</a></span>
				
				<div class="space30"></div>
				<button type="submit" class="btn btn-default add-to-cart" style="margin-top: 10px;"><i class="fa fa-check-square-o"></i> Pay Now</button>			
</form>	