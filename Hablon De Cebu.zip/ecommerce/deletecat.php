<?php
	session_start();
	require_once 'db.php';
	if(!isset($_SESSION['username']) & empty($_SESSION['username'])){
		header('location: index.php');
	}

	if(isset($_GET) & !empty($_GET)){
		$id = $_GET['id'];
		$sql = "DELETE FROM category WHERE id='$id'";
		if(mysqli_query($connection, $sql)){
			header('location: admincategory.php');
		}
	}else{
		header('location: admincategory.php');
	}
?>