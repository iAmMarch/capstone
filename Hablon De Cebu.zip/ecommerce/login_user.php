<?php 

include 'db.php';
if(isset($_POST) & !empty($_POST)){
$email = $_POST['email'];
$password = ($_POST['password']);

$sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
$result = mysqli_query($connection, $sql);
if ($result->num_rows > 0) 
	{
	while ($r = mysqli_fetch_assoc($result))
	{
		$username = $row['username'];
		session_start();
		$_SESSION['username'] = $r['username'];
		$_SESSION['customerid'] = $r['id'];

		header("Location: homepage_user.php?error=Success");
	}
	if ($_SESSION['username'] == "Admin")
	{
		header("Location: admin.php?disp=Admin");
	}
}

else{
	header("Location: index.php?error=Invalid Account");
}

}
?>