<?php 

	include("db.php");

if(isset($_GET['id']) & !empty($_GET['id'])){
	$id = $_GET['id'];
	$prodsql = "SELECT * FROM products WHERE id=$id";
	$prodres = mysqli_query($connection, $prodsql);
	$prodr = mysqli_fetch_assoc($prodres);
}else{
	header('location: details.php');
}
?>
<?php include('include/home/header.php'); ?>
	
	<section>
		<div class="container">
			<div class="row">
				<?php include('include/home/sidebar.php'); ?>
				<div class="col-sm-9 padding-right">
					<div class="product-details"><!--product-details-->
						<div class="col-sm-5">

						<div class="view-product">
  
                               <img src="<?php echo $prodr['thumb']; ?>" width="150" height="150">
						</div>
					</div>
						<div class="col-sm-7">
							<div class="product-information">

							<h2 class="product"><b>Product Name:</b> <?php echo $prodr['name']; ?></h2>
							<p><b>Category:</b> <?php 
								$prodcatsql = "SELECT * FROM category WHERE id={$prodr['catid']}"; 
								$prodcatres = mysqli_query($connection, $prodcatsql);
								$prodcatr = mysqli_fetch_assoc($prodcatres);
								?>
								<?php echo $prodcatr['name']; ?></p>
							<p><b>Price:</b> <span class="price"><?php echo $english_format_number = number_format($prodr['price']); ?></span></p>
							<p><b>Description: </b><?php echo $prodr['description']; ?></p>

							<form method="get" action="addtocart.php">
							<div class="product-quantity">
								<span>Quantity:</span> 
									<input type="hidden" name="id" value="<?php echo $prodr['id']; ?>">
									<input type="text" name="quant" placeholder="1">
							</div>
							<div class="shop-btn-wrap">
								<button type="submit" cclass="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i> Add to Cart</button>
							</div>
							</form>
						</div><!--/product-details-->
					
				</div>
			</div>

		</div>
	</section>