<?php include('include/admin/header.php'); ?>
<?php
    session_start();
    require_once 'db.php';
    if(!isset($_SESSION['username']) & empty($_SESSION['username'])){
        header('location: index.php');
    }
        if(isset($_POST) & !empty($_POST)){
        $name = mysqli_real_escape_string($connection, $_POST['categoryname']);
        $sql = "INSERT INTO category (name) VALUES ('$name')";
        $res = mysqli_query($connection, $sql);
        if($res){
            $smsg = "Category Added";
        }else{
            $fmsg = "Failed Add Category";
        }
    }
?>
<section>
		<div class="container">
			<div class="row">
                <?php include('include/admin/sidebar.php'); ?>
                <div class="col-sm-9 padding-right">
					<div class="features_items"><!--features_items-->
						<h2 class="title text-center">Category</h2>
                        <?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert"> <?php echo $fmsg; ?> </div><?php } ?>
        <?php if(isset($smsg)){ ?><div class="alert alert-success" role="alert"> <?php echo $smsg; ?> </div><?php } ?>                      
                        <form method="POST">
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon">Category Name:</div>
                                    <input type="text" class="form-control" name="categoryname" id="Categoryname" placeholder="Category Name">
                                    
                                </div>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn" name="addcategory">Submit</button>
                            </div>
                        </form>
                       <hr />
                        <table class="table table-bordered">
                            <thead class="bg-primary">
                                <th>Name</th>
                                <th colspan="2">Action</th>
                            </thead>
                            <tbody>
                            
                            <?php   
                    $sql = "SELECT * FROM category";
                    $res = mysqli_query($connection, $sql); 
                    while ($r = mysqli_fetch_assoc($res)) {
                ?>
                            <tr>
                                <td><?php echo $r['name'];?></td>    
                                <td><a href="editcategory.php?p=edit&&id=<?php echo $r['id']; ?>"><i class="fa fa-edit fa-lg text-success"><small>Edit</small></i></a></td>    
                                <td><a href="deletecat.php?p=delete&&table=category&&id=<?php echo $r['id']; ?>" class="confirm"><i class="fa fa-times-circle fa-lg text-danger"><small>Remove</small></i></a></td>    
                            </tr>
                        <?php } ?>
                            </tbody>
                        </table>

              </section>
