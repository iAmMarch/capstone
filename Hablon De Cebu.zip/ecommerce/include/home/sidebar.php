<?php include('db.php'); ?>

<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="left-sidebar">
						<h2>Category</h2>
                        <div class="list-group">
                           <?php
                            $catsql = "SELECT * FROM category order by name asc";
                            $catres = mysqli_query($connection, $catsql);

                            if($catres){



                            while($catr = mysqli_fetch_assoc($catres)){

                                echo '<a href="#?filter='.$catr['name'].'" class="list-group-item">'.$catr['name'].'</a>';
                                }
                            }


                         ?>
                          

                       
                        </div> 
                          <div class="list-group">
                        <a href="shop.php" class="btn btn-success"><span class="glyphicon glyphicon-refresh"></span> Refresh</a>
                         </div>
                        </div>
                        </div>

