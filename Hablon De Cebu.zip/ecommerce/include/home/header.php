<?PHP
if (!isset($_SESSION['cart'])) {
	$_SESSION['cart'] = array();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Hablon</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
</head><!--/head-->

<body>
<header id="header"><!--header-->
<div class="header_top">
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
						<div class="contactinfo">
							<ul class="nav nav-pills">
                            <li><a href="#"><i class="fa fa-phone"></i> 09224484660</a></li>
								<li><a href="#"><i class="fa fa-envelope"></i> cmarchp17@gmail.com</a></li>
							</ul>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="social-icons pull-right">
							<ul class="nav navbar-nav">
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
								<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
								<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
	<nav class="navbar navbar-inverse navabar-fixed-top">
               <div class="container">
                   <div class="navbar-header">
                       <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                           <span class="icon-bar"></span>
                           <span class="icon-bar"></span>
                           <span class="icon-bar"></span>
                       </button>
                       <a href="#" class="navbar-brand">Store</a>
                   </div>
                   
                   <div class="collapse navbar-collapse" id="myNavbar">
                       <ul class="nav navbar-nav navbar-right">
                            <li><a href="homepage_user.php"><span class=""></span> Home</a></li>
                            <li class="dropdown"><a href="shop.php">Shop<i class=""></i></a>
                                </li> 
                           <li><a href="cart.php"><span class=""></span> Cart</a></li>
                           <li><a href=""><span class=""></span> About Us</a></li>
                           <li><a href="#"><span class=""></span> Contact Us</a></li>
                           <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
                       </ul>
                   </div>
               </div>
	</nav>	
	<div class="header-middle">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="logo pull-left">
							<center><a href="index.php"><img src="img/headers.jpg" alt="" class="img-responsive"/></a></center>
						</div>
		
					</div>
					
				</div>
			</div>
		</div><!--/header-middle-->
        
	</header><!--/header-->
	