<!DOCTYPE html>
<html>
<head>
</head>
<body>
<div class="col-sm-3">
					<div class="left-sidebar">
						<h2>Admin Panel</h2>				 
    	                   <div class="list-group">
                               <a href="admin.php" class="list-group-item">Products</a>   
                               <a href="#" class="list-group-item">Orders</a> 
                               <a href="admincategory.php" class="list-group-item">Category</a>                                                                                                                           
                            </div>
                            <div class="list-group">
                               <a href="admin_logout.php" class="list-group-item active">Logout</a>
                            </div>
                        </div>
                        </div>
</body>