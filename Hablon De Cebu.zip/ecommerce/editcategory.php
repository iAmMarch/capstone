<?php include('include/admin/header.php'); ?>
<?php
    session_start();
    require_once 'db.php';
    if(!isset($_SESSION['username']) & empty($_SESSION['username'])){
        header('location: index.php');
    }

    if(isset($_GET) & !empty($_GET)){
        $id = $_GET['id'];
    }else{
        header('location: categories.php');
    }

    if(isset($_POST) & !empty($_POST)){
        $id = mysqli_real_escape_string($connection, $_POST['id']);
        $name = mysqli_real_escape_string($connection, $_POST['categoryname']);
        $sql = "UPDATE category SET name = '$name' WHERE id=$id";
        $res = mysqli_query($connection, $sql);
        if($res){
            $smsg = "Category Updated";
        }else{
            $fmsg = "Failed Update Category";
        }
    }
?>
<section>
		<div class="container">
			<div class="row">
                <?php include('include/admin/sidebar.php'); ?>
                <div class="col-sm-9 padding-right">
					<div class="features_items"><!--features_items-->
						<h2 class="title text-center">Category</h2> 
                        <?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert"> <?php echo $fmsg; ?> </div><?php } ?>
        <?php if(isset($smsg)){ ?><div class="alert alert-success" role="alert"> <?php echo $smsg; ?> </div><?php } ?>                     
                        <form method="POST">
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon">Category Name:</div>
                                     <?php  
                    $sql = "SELECT * FROM category WHERE id=$id";
                    $res = mysqli_query($connection, $sql); 
                    $r = mysqli_fetch_assoc($res); 
                ?>
                                 <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">
                <input type="text" class="form-control" name="categoryname" id="Categoryname" placeholder="Category Name" value="<?php echo $r['name'];  ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-default">Update</button>
                                <a href="admincategory.php" class="btn btn-success">Add Category</a>
                            </div>
                        </form>
                       <hr />

              </section>
